export const API_URL = "https://goweather.herokuapp.com/"
export const CITIES_TO_DISPLAY = ["Berlin", "Paris", "London"]